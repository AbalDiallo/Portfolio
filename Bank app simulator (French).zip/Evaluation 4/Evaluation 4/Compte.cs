﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Evaluation_4
{
    internal class Compte //creer une classe compte
    {
        public double argent { get; set; } //propriété d'argent
        public long nCompte { get; set; } //propriété numero de compte
        public string nom { get; set; } //propriété nom
        public string prenom { get; set; } //propriété prenom

        public Compte(double argent, long nCompte, string nom, string prenom) //constructeur
        {
            this.nom = nom; //obtenir la valeure
            this.prenom = prenom; //obtenir la valeure
            this.argent = argent; //obtenir la valeure
            this.nCompte = nCompte; //obtenir la valeure
        }

        public void virement(bool v, double transaction) //methode de virement
        {
            while (!v) //repeter jusqu'a la boucle accepte une valeure
            {
                Console.WriteLine("Combien d'argent voulez vous virer?"); //demander a l'utilisateur combien d"argent ils veulent virer
                v = double.TryParse(Console.ReadLine(), out transaction); //tryparse avec le montant de la transaction
                if (v == false) //si le tryparse ne fonctionne pas
                    Console.WriteLine("Cela n'est pas un montant valide d'argent"); //dire a l'utilisateur que le montant choisi n'est pas valide
                else //si le tryparse fonctionne
                {
                    if (transaction < 0) //si le montant voulu de la transaction est plus grand que 0
                    {
                        Console.WriteLine("Vous ne pouver pas virer un montant negative d'argent"); //dire a l'utilisateur qu'il doit virer un montant positive d'argent
                        v = false; //repeter la boucle
                    }
                    else
                    {
                        this.argent = this.argent + transaction; //ajouter le montant choisi a la solde
                        v = true; //quitter la boucle while
                    }
                }
            }
        }

        public void retirement(bool v, double transaction)
        {
            while (!v) //repeter jusqu'a la boucle accepte une valeure
            {
                Console.WriteLine("Combien d'argent voulez vous retirer?"); //demander a l'utilisateur combien d"argent il veut retirer
                v = double.TryParse(Console.ReadLine(), out transaction); //tryparse avec le montant de la transaction
                if (v == false) //si le tryparse ne fonctionne pas
                    Console.WriteLine("Cela n'est pas un montant valide d'argent"); //dire a l'utilisateur que le montant choisi n'est pas valide
                else //si le tryparse fonctionne
                {
                    if (transaction > this.argent) //si le montant voulu de la transaction est plus grand que le montant d'argent dans le compte et le montant est plus grand que 0
                    {                        
                        Console.WriteLine("Vous n'avez pas assez d'argent pour cette transaction"); //dire a l'utilisateur qu'il n'a pas assez d'argent
                        v = false; //repeter la boucle
                    }
                    else if (transaction < 0) //si le montant voulu de la transaction est plus grand que 0
                    {
                        Console.WriteLine("Vous ne pouver pas retirer un montant negative d'argent"); //dire a l'utilisateur qu'il doit retirer un montant positive
                        v = false; //repeter la boucle
                    }
                    else
                    {
                        this.argent = this.argent - transaction; //soustraire le montant choisi a la solde
                        v = true; //quitter la boucle
                    }
                }
            }
        }

        public void informations() //methode pour l'information du compte
        {
            Console.WriteLine("{0}\nBienvenue a la Banque Super d'Ottawa! (SRO)\n{0}", "-------------------------------------------"); //ecrire le titre
            Console.WriteLine("Informations sur votre compte:\n{0}", "-------------------------------------------"); //ecrire le sous titre
            Console.WriteLine("Nom: {0}\nPrenom: {1}\nNumero de Compte: {2}\nSolde: {3}$\n", nom, prenom, nCompte, argent); //ecrire les informations
            Console.WriteLine("Que voulez vous faire?\n\t1-Virement\n\t2-Retrait\n\t3-Fermer l'application"); //ecrire les options de l'utilisateur
        }
    }   
}
