﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evaluation_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("{0}\nBienvenue a la Banque Super d'Ottawa! (SRO)\n{0}", "-------------------------------------------"); //ecrire le titre

            long nCompte = 0; //integer pour un numero de compte
            bool v = false; //booleen pour verifier le status de parse

            Console.WriteLine("Veuillez entrer votre nom"); //demander a l'utilisateur leur nom
            string nom = Console.ReadLine(); //lire le nom de l'utilisateur
            Console.WriteLine("Veuillez entrer votre prenom"); //demander a l'utilisateur leur prenom
            string prenom = Console.ReadLine(); //lire le prenom de l'utilisateur
            while (!v) //tant que parse n'est pas complet
            {
                Console.WriteLine("Veuillez entrer votre numero de compte"); //demander a l'utisateur leur numero de compte
                string saisie = Console.ReadLine(); //lire la console
                v = long.TryParse(saisie, out nCompte); //tryparse avec le nombre de compte
                if (v == false) //si le tryparse ne fonctionne pas
                    Console.WriteLine("Cela n'est pas un numero de compte valide"); //dire a l'utilisateur que le numero de compte n'est pas valide
            }
            Compte compte = new Compte(500, nCompte, nom, prenom); //declarer la classe

            while (true) //boucle eternelle
            {
                Console.Clear(); //vider la console
                compte.informations(); //appeler la methode pour les informations du compte
                bool choix = false; //commencer le loop while suivant

                while (!choix) //pendant que la booleen choix est false
                {
                    string saisie = Console.ReadLine(); //lire le choix de l'utilisateur
                    if (saisie == "1") //si l'utilisateur choisi un virement
                    {
                        compte.virement(false, 0); //appeler la methode de virement
                        choix = true; //sortir de la boucle while
                    }
                    else if (saisie == "2") //si l'utilisateur choisi un retirement
                    {
                        compte.retirement(false, 0); //appeler la methode de retirement
                        choix = true; //sortir de la boucle while
                    }
                    else if (saisie == "3") //si l'utilisateur choisi de fermer le code
                    {
                        Console.WriteLine("Merci pour avoir utiliser la Banque EML, l'application ce fermera bientot..."); //message de confirmation pour l'utilisateur
                        Environment.Exit(0); //fermer la console
                    }
                    else //si l'utilisateur choisi une option invalide
                        Console.WriteLine("Cela n'est pas une option valide"); //dire a l'utilisateur que leur option n'est pas valid et recommencer le code
                }
            }          
        }        
    }
}
