﻿namespace Evaluation_Final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerLabel = new System.Windows.Forms.Label();
            this.newHsLabel = new System.Windows.Forms.Label();
            this.highscoreLabel = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.countdownTimer = new System.Windows.Forms.Timer(this.components);
            this.titleLabel = new System.Windows.Forms.Label();
            this.questionPictureBox = new System.Windows.Forms.PictureBox();
            this.playPictureBox = new System.Windows.Forms.PictureBox();
            this.laserPictureBox = new System.Windows.Forms.PictureBox();
            this.ufoPictureBox = new System.Windows.Forms.PictureBox();
            this.shipPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.questionPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.laserPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // timerLabel
            // 
            this.timerLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.timerLabel.AutoSize = true;
            this.timerLabel.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timerLabel.ForeColor = System.Drawing.Color.White;
            this.timerLabel.Location = new System.Drawing.Point(568, 20);
            this.timerLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.timerLabel.Name = "timerLabel";
            this.timerLabel.Size = new System.Drawing.Size(25, 19);
            this.timerLabel.TabIndex = 15;
            this.timerLabel.Text = "30";
            this.timerLabel.Visible = false;
            // 
            // newHsLabel
            // 
            this.newHsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.newHsLabel.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newHsLabel.ForeColor = System.Drawing.Color.White;
            this.newHsLabel.Location = new System.Drawing.Point(216, 20);
            this.newHsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.newHsLabel.MinimumSize = new System.Drawing.Size(188, 41);
            this.newHsLabel.Name = "newHsLabel";
            this.newHsLabel.Size = new System.Drawing.Size(193, 41);
            this.newHsLabel.TabIndex = 14;
            this.newHsLabel.Text = "Highscore: 0";
            this.newHsLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // highscoreLabel
            // 
            this.highscoreLabel.AutoSize = true;
            this.highscoreLabel.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highscoreLabel.ForeColor = System.Drawing.Color.White;
            this.highscoreLabel.Location = new System.Drawing.Point(10, 43);
            this.highscoreLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.highscoreLabel.Name = "highscoreLabel";
            this.highscoreLabel.Size = new System.Drawing.Size(87, 19);
            this.highscoreLabel.TabIndex = 13;
            this.highscoreLabel.Text = "HighScore: 0";
            this.highscoreLabel.Visible = false;
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Font = new System.Drawing.Font("Impact", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.ForeColor = System.Drawing.Color.White;
            this.scoreLabel.Location = new System.Drawing.Point(10, 20);
            this.scoreLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(59, 19);
            this.scoreLabel.TabIndex = 12;
            this.scoreLabel.Text = "Score: 0";
            this.scoreLabel.Visible = false;
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 25;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
            // 
            // countdownTimer
            // 
            this.countdownTimer.Enabled = true;
            this.countdownTimer.Interval = 1000;
            this.countdownTimer.Tick += new System.EventHandler(this.countdownTimer_Tick);
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Nirmala UI", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.titleLabel.Location = new System.Drawing.Point(91, 61);
            this.titleLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(468, 86);
            this.titleLabel.TabIndex = 17;
            this.titleLabel.Text = "Space Shooter";
            // 
            // questionPictureBox
            // 
            this.questionPictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.questionPictureBox.Image = global::Evaluation_Final.Properties.Resources.QuestionMark;
            this.questionPictureBox.Location = new System.Drawing.Point(523, 289);
            this.questionPictureBox.Name = "questionPictureBox";
            this.questionPictureBox.Size = new System.Drawing.Size(65, 65);
            this.questionPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.questionPictureBox.TabIndex = 18;
            this.questionPictureBox.TabStop = false;
            this.questionPictureBox.Click += new System.EventHandler(this.questionPictureBox_Click);
            // 
            // playPictureBox
            // 
            this.playPictureBox.Image = global::Evaluation_Final.Properties.Resources.Space5;
            this.playPictureBox.Location = new System.Drawing.Point(221, 188);
            this.playPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.playPictureBox.Name = "playPictureBox";
            this.playPictureBox.Size = new System.Drawing.Size(210, 98);
            this.playPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playPictureBox.TabIndex = 16;
            this.playPictureBox.TabStop = false;
            this.playPictureBox.Click += new System.EventHandler(this.playPictureBox_Click);
            // 
            // laserPictureBox
            // 
            this.laserPictureBox.Image = global::Evaluation_Final.Properties.Resources.Space3;
            this.laserPictureBox.Location = new System.Drawing.Point(555, 209);
            this.laserPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.laserPictureBox.Name = "laserPictureBox";
            this.laserPictureBox.Size = new System.Drawing.Size(4, 24);
            this.laserPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.laserPictureBox.TabIndex = 11;
            this.laserPictureBox.TabStop = false;
            this.laserPictureBox.Visible = false;
            // 
            // ufoPictureBox
            // 
            this.ufoPictureBox.Image = global::Evaluation_Final.Properties.Resources.Space2;
            this.ufoPictureBox.Location = new System.Drawing.Point(40, 171);
            this.ufoPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.ufoPictureBox.Name = "ufoPictureBox";
            this.ufoPictureBox.Size = new System.Drawing.Size(71, 73);
            this.ufoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ufoPictureBox.TabIndex = 10;
            this.ufoPictureBox.TabStop = false;
            this.ufoPictureBox.Visible = false;
            // 
            // shipPictureBox
            // 
            this.shipPictureBox.Image = global::Evaluation_Final.Properties.Resources.Space1;
            this.shipPictureBox.Location = new System.Drawing.Point(40, 257);
            this.shipPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.shipPictureBox.Name = "shipPictureBox";
            this.shipPictureBox.Size = new System.Drawing.Size(64, 77);
            this.shipPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.shipPictureBox.TabIndex = 9;
            this.shipPictureBox.TabStop = false;
            this.shipPictureBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(20)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.questionPictureBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.playPictureBox);
            this.Controls.Add(this.timerLabel);
            this.Controls.Add(this.newHsLabel);
            this.Controls.Add(this.highscoreLabel);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.laserPictureBox);
            this.Controls.Add(this.ufoPictureBox);
            this.Controls.Add(this.shipPictureBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Space Shooter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.questionPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.laserPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label timerLabel;
        private System.Windows.Forms.Label newHsLabel;
        private System.Windows.Forms.Label highscoreLabel;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.PictureBox laserPictureBox;
        private System.Windows.Forms.PictureBox ufoPictureBox;
        private System.Windows.Forms.PictureBox shipPictureBox;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Timer countdownTimer;
        private System.Windows.Forms.PictureBox playPictureBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.PictureBox questionPictureBox;
    }
}

