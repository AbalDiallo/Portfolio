﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evaluation_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        bool moveUp, moveDown, moveLeft, moveRight, shoot, ufoDirection, gameState;

        int score, highscore, ufoMove, timerTime;

        private SoundPlayer laserShoot = new SoundPlayer(Properties.Resources.LaserShoot);
        private SoundPlayer laserHit = new SoundPlayer(Properties.Resources.LaserHit);

        private void Form1_Load(object sender, EventArgs e)
        {
            titleLabel.Left = ClientSize.Width / 2 - titleLabel.Width / 2;
            titleLabel.Top = ClientSize.Height / 6;
            playPictureBox.Left = ClientSize.Width / 2 - playPictureBox.Width / 2;
            playPictureBox.Top = ClientSize.Height - playPictureBox.Height * 2;
        }
        private void playPictureBox_Click(object sender, EventArgs e)
        {
            gameState = true;
            score = 0;
            timerTime = 30;
            playPictureBox.Visible = false;
            titleLabel.Visible = false;
            newHsLabel.Visible = false;
            questionPictureBox.Visible = false;
            shipPictureBox.Left = ClientSize.Width / 2 - shipPictureBox.Width / 2;
            ufoPictureBox.Top = ClientSize.Height / 4;
        }

        private void questionPictureBox_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Up: Move up\nDown: Move down\nLeft: Move left\nRight: Move right\nSpace: Shoot\n\nYour goal is to hit the alien, every successful shot will give you 100 points while every miss will remove 50");
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            ufoPictureBox.Top = ClientSize.Height / 4;
            shipPictureBox.Top = ClientSize.Height - ClientSize.Height / 3;
            shipPictureBox.Left = ClientSize.Width / 2 - shipPictureBox.Width / 2;
            titleLabel.Left = ClientSize.Width / 2 - titleLabel.Width / 2;
            titleLabel.Top = ClientSize.Height / 6;
            playPictureBox.Left = ClientSize.Width / 2 - playPictureBox.Width / 2;
            playPictureBox.Top = ClientSize.Height - playPictureBox.Height * 2;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                moveUp = true;
            if (e.KeyCode == Keys.Down)
                moveDown = true;
            if (e.KeyCode == Keys.Left)
                moveLeft = true;
            if (e.KeyCode == Keys.Right)
                moveRight = true;
            if (e.KeyCode == Keys.Space)
            {
                if (shoot == false && gameState == true)
                {
                    laserPictureBox.Left = shipPictureBox.Left + shipPictureBox.Width / 2;
                    laserPictureBox.Top = shipPictureBox.Top - laserPictureBox.Height;
                    laserPictureBox.Show();
                    laserShoot.Play();
                }
                shoot = true;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                moveUp = false;
            if (e.KeyCode == Keys.Down)
                moveDown = false;
            if (e.KeyCode == Keys.Left)
                moveLeft = false;
            if (e.KeyCode == Keys.Right)
                moveRight = false;
        }
        private void gameTimer_Tick(object sender, EventArgs e)
        {
            scoreLabel.Text = ("Score: " + score);
            highscoreLabel.Text = ("Highscore: " + highscore);
            if (score >= highscore && score != 0)
            {
                highscore = score;
                newHsLabel.Text = ("NEW HIGHSCORE");
                newHsLabel.Visible = true;
            }
            else
                newHsLabel.Visible = false;

            if (moveUp == true && shipPictureBox.Top > ClientSize.Height - ClientSize.Height / 3)
                shipPictureBox.Top -= 7;
            if (moveDown == true && shipPictureBox.Top < ClientSize.Height - shipPictureBox.Height / 2)
                shipPictureBox.Top += 7;
            if (moveLeft == true && shipPictureBox.Left > 0 - shipPictureBox.Width / 2)
                shipPictureBox.Left -= 7;
            if (moveRight == true && shipPictureBox.Left < ClientSize.Width - shipPictureBox.Width / 2)
                shipPictureBox.Left += 7;

            if (ufoMove == 0)
            {
                if (ufoDirection == false)
                    ufoPictureBox.Left -= 5;
                else
                    ufoPictureBox.Left += 5;
            }
            else if (ufoMove == 30)
            {
                if (ufoDirection == false)
                    ufoPictureBox.Left = ClientSize.Width;
                else if (ufoDirection == true)
                    ufoPictureBox.Left = 0 - ufoPictureBox.Width;
                ufoPictureBox.Image = Properties.Resources.Space2;
                ufoMove = -10;
            }
            else
            {
                ufoMove++;
            }

            if (ufoPictureBox.Left + ufoPictureBox.Width < -20 || ufoPictureBox.Left - 20 > ClientSize.Width)
            {
                if (ufoDirection == true)
                    ufoPictureBox.Left = ClientSize.Width;
                else if (ufoDirection == false)
                    ufoPictureBox.Left = 0 - ufoPictureBox.Width;
                ufoPictureBox.Image = Properties.Resources.Space2;
                ufoDirection = rnd.NextDouble() > 0.5;
            }

            if (shoot == true)
            {
                if (laserPictureBox.Bounds.IntersectsWith(ufoPictureBox.Bounds))
                {
                    score += 100;
                    laserHit.Play();
                    laserPictureBox.Hide();
                    shoot = false;
                    ufoMove = 1;
                    ufoDirection = rnd.NextDouble() > 0.5;
                    ufoPictureBox.Image = Properties.Resources.Space4V2;
                }
                if (laserPictureBox.Top > 0 - laserPictureBox.Height)
                {
                    laserPictureBox.Top -= 9;
                }
                else
                {
                    laserPictureBox.Hide();
                    shoot = false;
                    score -= 50;
                }
            }
        }
        private void countdownTimer_Tick(object sender, EventArgs e)
        {
            timerLabel.Text = timerTime.ToString();
            timerTime--;

            if (timerTime == -2)
                gameState = false;

            if (gameState == false)
            {
                scoreLabel.Visible = false;
                highscoreLabel.Visible = false;
                timerLabel.Visible = false;
                shipPictureBox.Visible = false;
                ufoPictureBox.Visible = false;
                laserPictureBox.Visible = false;

                playPictureBox.Visible = true;
                titleLabel.Visible = true;
                newHsLabel.Visible = true;
                questionPictureBox.Visible = true;

                gameTimer.Enabled = false;

                newHsLabel.Text = ("Highscore: " + highscore);
                newHsLabel.ForeColor = Color.White;
            }
            else
            {
                scoreLabel.Visible = true;
                highscoreLabel.Visible = true;
                timerLabel.Visible = true;
                shipPictureBox.Visible = true;
                ufoPictureBox.Visible = true;

                playPictureBox.Visible = false;
                titleLabel.Visible = false;
                questionPictureBox.Visible = false;

                gameTimer.Enabled = true;

                if(newHsLabel.ForeColor == Color.Red)
                    newHsLabel.ForeColor = Color.Yellow;
                else
                    newHsLabel.ForeColor = Color.Red;
            }
        }
    }
}
