﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace devoir_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Temperature temperature = new Temperature(); //cree un objet pour la classe
            Console.WriteLine("\t-------------------------\n\tConversion de Temperature\n\t-------------------------"); //afficher le titre

            while (true) //toujours repeter
            {
                Console.WriteLine("Options:\n\t Choisir une des option suivantes:\n\t\t1-Conversion des degrés celcius en Farenheit\n\t\t2-Conversion Farenheit a degrés celcius\n\t\tQ-Quitter la console"); //donner a l'utilisateur ses options
                temperature.Conversion(Console.ReadLine()); //lire le choix de l'utilisateur
            }
        }
    }
}
