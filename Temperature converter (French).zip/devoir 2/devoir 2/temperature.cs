﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace devoir_2
{
    internal class Temperature
    {
        public void Conversion(string saisie) //methode pour les choix de l'utilisateur
        {
            {
                if (saisie == "1") //si l'utilisateur choisi la premiere option
                {
                    CelciusAFarenheit(); //appeler la methode pour transformer les degres celcius a Farenheit
                }
                else if (saisie == "2") //si l'utilisateur choisi la deuxieme option
                {
                    FarenheitACelcius(); //appeler la methode pour transformer les Farenheit au degres celcius
                }
                else if (saisie == "Q") //si l'utilisateur choisi la troixieme option
                {
                    Console.WriteLine("Merci pour avoir utilisé notre programme, l'aplication ce fermera"); //remercier l'utilisateur pour avoir utilise notre application
                    Environment.Exit(1); //fermer la console
                }
                else //si l'utilisateur n'a pas choisi une des option
                {
                    Console.WriteLine("Cela n'est pas une option, veuillez choisir une autre option"); //demander a l'utilisateur de choisir une autre option
                }
            }
        }

        public void CelciusAFarenheit() //methode pour convertir de degres celcius en Farenheit
        {
            Console.WriteLine("Entrez la température en degrés celcius"); //donner l'instruction a l'utilisateur
            double.TryParse(Console.ReadLine(), out double degres); //obtenir et parse l'entree de l'utilisateur
            degres = (degres * 1.8) + 32; //calculation de conversion celcius a Farenheit
            Console.WriteLine("{0}°F", degres); //afficher la temperature en Farenheit
        }
        public void FarenheitACelcius() //methode pour convertir de Farenheit en degres celcius
        {
            Console.WriteLine("Entrez la température en degrés Farenheit"); //donner l'instruction a l'utilisateur
            double.TryParse(Console.ReadLine(), out double degres); //obtenir et parse l'entree de l'utilisateur
            degres = (degres - 32) * 0.555555; //calculation de conversion Farenheit au degres celcius
            Console.WriteLine("{0}°C", degres); //afficher la temperature en degres celcius
        }
        
    }
}
